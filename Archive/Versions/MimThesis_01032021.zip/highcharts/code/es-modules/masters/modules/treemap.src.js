/**
 * @license Highcharts JS v9.0.1 (2021-02-15)
 * @module highcharts/modules/treemap
 * @requires highcharts
 *
 * (c) 2014-2021 Highsoft AS
 * Authors: Jon Arild Nygard / Oystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Series/Treemap/TreemapSeries.js';
