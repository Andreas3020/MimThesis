/**
 * @license Highcharts Gantt JS v9.0.1 (2021-02-15)
 * @module highcharts/modules/current-date-indicator
 * @requires highcharts
 *
 * CurrentDateIndicator
 *
 * (c) 2010-2021 Lars A. V. Cabrera
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/CurrentDateIndication.js';
