/**
 * @license Highcharts JS v9.0.1 (2021-02-15)
 * @module highcharts/themes/high-contrast-light
 * @requires highcharts
 *
 * (c) 2009-2021 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../Extensions/Themes/HighContrastLight.js';
